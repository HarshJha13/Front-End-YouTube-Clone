var menuIcon = document.querySelector(".menu-icon");
var sidebar = document.querySelector(".sidebar");
var container = document.querySelector(".container");
let likebtn = document.querySelector("#likebtn");
let dislikebtn = document.querySelector("#dislikebtn");
let input1 = document.querySelector("#input1");
let input2 = document.querySelector("#input2");

likebtn.addEventListener('click',()=>{
    input1.value = parseInt(input1.value) + 1;
    input1.style.color = "black";
})
dislikebtn.addEventListener('click',()=>{
    input2.value = parseInt(input2.value) + 1;
    input2.style.color = "black";
})



menuIcon.onclick = function(){
    sidebar.classList.toggle("small-sidebar");
    container.classList.toggle("large-container");
}




